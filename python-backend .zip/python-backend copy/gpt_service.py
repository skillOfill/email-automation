from fastapi import FastAPI
from pydantic import BaseModel
import requests
import os
from dotenv import load_dotenv

# Load API key from .env file
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")

if not GEMINI_API_KEY:
    raise ValueError("API Key not found! Please set GEMINI_API_KEY in your .env file.")

# Define FastAPI app
app = FastAPI()

class EmailRequest(BaseModel):
    email_id: str
    purpose: str
    tone: str
    description: str

@app.post("/generate-email")
async def generate_email(request: EmailRequest):
    email_id = request.email_id
    purpose = request.purpose
    tone = request.tone
    description = request.description

    # Gemini API URL
    GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={GEMINI_API_KEY}"

    # API Request body
    prompt_text = (
        f"Generate a {tone} email to {email_id} regarding {purpose}. "
        f"Email content: {description}. Format it professionally with subject, greeting, "
        f"body, and signature."
    )

    payload = {
        "contents": [{"parts": [{"text": prompt_text}]}]
    }

    headers = {"Content-Type": "application/json"}

    # API Call
    try:
        response = requests.post(GEMINI_URL, json=payload, headers=headers)
        response_data = response.json()

        # Extract response
        if "candidates" in response_data:
            generated_email = response_data["candidates"][0]["content"]["parts"][0]["text"]
            return {"generated_email": generated_email}
        else:
            return {"error": "Failed to generate email", "details": response_data}

    except Exception as e:
        return {"error": f"Error communicating with Gemini API: {str(e)}"}
