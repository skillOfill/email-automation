module.exports = {
  plugins: [
    require('@tailwindcss/postcss'), // Use the correct Tailwind PostCSS package
    require('autoprefixer'),
  ]
}