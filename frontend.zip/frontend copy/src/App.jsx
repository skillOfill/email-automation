import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Dashboard from "./pages/Dashboard";

function App() {
  return (
    <Router>
      <Routes>
        {/* Default route - Directly open Dashboard */}
        <Route path="/" element={<Dashboard />} />

        {/* Dashboard - Accessible without authentication */}
        <Route path="/dashboard/*" element={<Dashboard />} />

        {/* Commented out authentication-related routes */}
        {/*
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        */}
      </Routes>
    </Router>
  );
}

export default App;