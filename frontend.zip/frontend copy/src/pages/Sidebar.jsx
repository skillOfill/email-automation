import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import "../styles/sidebar.css";

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation(); // Get the current route

  return (
    <div className={`sidebar ${collapsed ? "collapsed" : ""}`}>
      <button className="toggle-btn" onClick={() => setCollapsed(!collapsed)}>
        {collapsed ? "➡" : "⬅"}
      </button>
      <h2 className="sidebar-title">Dashboard</h2>
      <ul>
        <li className={location.pathname === "/dashboard/overview" ? "active" : ""}>
          <Link to="/dashboard/overview">Overview</Link>
        </li>
        <li className={location.pathname === "/dashboard/analytics" ? "active" : ""}>
          <Link to="/dashboard/analytics">Analytics</Link>
        </li>
        <li className={location.pathname === "/dashboard/settings" ? "active" : ""}>
          <Link to="/dashboard/settings">Settings</Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;