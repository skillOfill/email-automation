import { useNavigate } from "react-router-dom";

function Home() {
  const navigate = useNavigate();

  return (
    <div>
      <h1>Welcome to Sales AI</h1>
      <button onClick={() => navigate("/")}>Logout</button>
    </div>
  );
}

export default Home;