import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import Sidebar from "./Sidebar";
import "../styles/dashboard.css";

const Dashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const [emailId, setEmailId] = useState("");
  const [purpose, setPurpose] = useState("");
  const [tone, setTone] = useState("Formal");
  const [description, setDescription] = useState("");
  const [generatedEmail, setGeneratedEmail] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  const handleGenerateEmail = async () => {
    if (!emailId || !purpose || !description) {
      alert("Please fill all required fields.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("http://localhost:8080/api/email/generate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          recipientEmail: emailId,  // Matches backend
          subject: purpose,         // Matches backend
          tone: tone,
          description: description,
      }),
      });

      if (!response.ok) {
        throw new Error("Failed to generate email");
      }

      const data = await response.json();
      setGeneratedEmail(data.generated_email || "Error generating email");
    } catch (error) {
      console.error("Error:", error);
      setGeneratedEmail("Failed to generate email.");
    }

    setLoading(false);
  };

  return (
    <div className="dashboard-container">
      <Sidebar />

      <div className="dashboard-content">
        <div className="dashboard-header">
          <h1>Dashboard</h1>
          <button className="logout-btn" onClick={handleLogout}>
            Logout
          </button>
        </div>

        <div className="dashboard-body">
          <p>Welcome to your Sales Automation Dashboard!</p>

          <div className="email-generator">
            <h3>Generate Sales Email</h3>

            <input
              type="email"
              value={emailId}
              onChange={(e) => setEmailId(e.target.value)}
              placeholder="Enter recipient email"
              className="email-input"
            />

            <input
              type="text"
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              placeholder="Enter email purpose (e.g., Meeting Request)"
              className="email-input"
            />

            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="email-input"
            >
              <option value="Formal">Formal</option>
              <option value="Casual">Casual</option>
            </select>

            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Enter email description here..."
              className="email-input"
            />

            <button onClick={handleGenerateEmail} className="generate-btn" disabled={loading}>
              {loading ? "Generating..." : "Generate Email"}
            </button>

            {generatedEmail && (
              <div className="generated-email">
                <h4>Generated Email:</h4>
                <div dangerouslySetInnerHTML={{ __html: generatedEmail }} />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
