package com.example.demo.salesautomation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.salesautomation.SalesAutomationApplication;

@SpringBootTest(classes = SalesAutomationApplication.class)
class DemoApplicationTests {

    @Test
    void contextLoads() {
    }
}