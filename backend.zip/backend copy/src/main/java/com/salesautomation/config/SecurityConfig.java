package com.salesautomation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf(csrf -> csrf.disable()) // ✅ Disable CSRF for APIs
            .cors(cors -> cors.and())  // ✅ Ensure CORS is handled separately in CorsConfig
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/users/signup", "/api/users/login").permitAll() // ✅ Allow signup/login
                .requestMatchers("/api/auth/**").permitAll() // ✅ Allow authentication routes
                .requestMatchers("/api/email/generate").permitAll() // ⬅️ ALLOW email generation without authentication
                .anyRequest().permitAll() // ⬅️ ALLOW ALL ROUTES (skipping authentication)
            );

        return http.build();
    }
}