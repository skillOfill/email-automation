package com.salesautomation.controller;

import com.salesautomation.service.EmailService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/email")
public class EmailController {

    private final EmailService emailService;

    public EmailController(EmailService emailService) {
        this.emailService = emailService;
    }

    @PostMapping("/generate")
    public ResponseEntity<Map<String, String>> generateEmail(@RequestBody Map<String, String> requestBody) {
        String recipientEmail = requestBody.get("recipientEmail");
        String subject = requestBody.get("subject");
        String tone = requestBody.get("tone");
        String description = requestBody.get("description");

        if (recipientEmail == null || subject == null || tone == null || description == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "All fields are required"));
        }

        String generatedEmail = emailService.generateEmail(recipientEmail, subject, tone, description);
        return ResponseEntity.ok(Map.of("generated_email", generatedEmail));
    }
}
