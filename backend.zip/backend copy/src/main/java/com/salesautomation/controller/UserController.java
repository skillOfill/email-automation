package com.salesautomation.controller;

import com.salesautomation.model.User;
import com.salesautomation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    // ✅ User Signup - Accepts Name, Email, Password
    @PostMapping("/signup")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        Optional<User> existingUser = userService.getUserByEmail(user.getEmail());

        if (existingUser.isPresent()) {
            return ResponseEntity.badRequest().body(Map.of(
                "success", false,
                "message", "User already exists"
            ));
        }

        userService.registerUser(user);
        return ResponseEntity.ok(Map.of(
            "success", true,
            "message", "User registered successfully"
        ));
    }

    // ✅ Secure User Login - Returns a token (dummy for now)
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User user) {
        boolean isValid = userService.validateUser(user.getEmail(), user.getPassword());

        if (isValid) {
            return ResponseEntity.ok(Map.of(
                "success", true,
                "message", "Login successful",
                "token", "dummy_token_123" // 🔥 Replace with real JWT later
            ));
        }

        return ResponseEntity.badRequest().body(Map.of(
            "success", false,
            "message", "Invalid email or password"
        ));
    }
}
