package com.salesautomation.service;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import java.util.Map;

@Service
public class EmailService {

    private final RestTemplate restTemplate = new RestTemplate();
    private final String PYTHON_API_URL = "http://127.0.0.1:8000/generate-email";

    public String generateEmail(String email, String purpose, String tone, String description) {
        // Prepare request body
        Map<String, String> requestBody = Map.of(
            "email_id", email,
            "purpose", purpose,
            "tone", tone,
            "description", description
        );

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        
        // Create HTTP entity with body and headers
        HttpEntity<Map<String, String>> entity = new HttpEntity<>(requestBody, headers);
        
        try {
            // Send request to Python backend
            ResponseEntity<Map> response = restTemplate.exchange(
                PYTHON_API_URL, HttpMethod.POST, entity, Map.class
            );
            
            // Extract the generated email from response
            if (response.getBody() != null) {
                Object generatedEmail = response.getBody().get("generated_email");
                return generatedEmail != null ? generatedEmail.toString() : "Error: No email generated";
            } else {
                return "Error: No response from backend";
            }
        } catch (Exception e) {
            return "Error communicating with AI model: " + e.getMessage();
        }
    }
}
